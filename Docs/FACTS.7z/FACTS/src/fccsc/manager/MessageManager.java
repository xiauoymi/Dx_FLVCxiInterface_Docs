package fccsc.manager;

import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;

import org.apache.log4j.*;

import intarsys.util.PropertyManager;

import fccsc.manager.crypto.MessageCryptography;
import fccsc.manager.util.*;


public final class MessageManager
	extends Thread
{
    private static Logger logger = Logger.getLogger( MessageManager.class );

	private static ThreadGroup threadGroup = new ThreadGroup( "BALONIE" );
	private static boolean     listening   = false;

	private ServerSocket server    = null;
	private Socket       client    = null;


	/**
	 * Entry point for application.
	 *
	 * @param args no parameters required.
	 */
	public static void
	main( String [] args )
	{
		new MessageManager();
	}


	/**
	 * Instantiates a new MessageManager object and performs the following:
	 * - loads configuration data from property files,
	 * - loads data wrapping templates for required message processes,
	 * - and creates / manages *.logs files for logging events.
	 *
	 * The following required directories must exist relative to the current directory:
	 *
	 * /properties - contains all configuration *.properties files
	 * /templates  - contains all data wrapping *.template files
	 * /logs       - location for all *.logs files to be managed by Log4j
	 */
    public
	MessageManager()
	{
		try
		{
			///////////////////////////////////////////////////////////////
			// get the current directory path
			File f = new File( "." );

			///////////////////////////////////////////////////////////////
			// load the templates into memory
			//
			TemplateManager.init( f.getCanonicalPath() + f.separator + "templates" );
			TemplateManager.loadAll();

			///////////////////////////////////////////////////////////////
			// load the properties files
			// and fetch parameter values for this object's construction
			//
			PropertyManager.init( f.getCanonicalPath() + f.separator + "properties" );
			PropertyManager.loadAll();

			///////////////////////////////////////////////////////////////
			// load the log4j properties
			//
			Properties propLog4j = (Properties) PropertyManager.getProperty( "log4j.properties" );
		    PropertyConfigurator.configure( propLog4j );

			///////////////////////////////////////////////////////////////
			// initialize our cryptography object
			//
			Properties propCrypto = ( Properties ) PropertyManager.getProperty( "cryptography.properties" );
		    MessageCryptography.init( propCrypto );

			///////////////////////////////////////////////////////////////
			// load property object and read parameters
			//
			Properties prop    = (Properties) PropertyManager.getProperty( "manager.properties" );
			int        port    = (int) Integer.parseInt( (String) prop.getProperty( "manager.listener.port"    ) );
			int        backLog = (int) Integer.parseInt( (String) prop.getProperty( "manager.listener.backlog" ) );

			server    = new ServerSocket( port, backLog );
			listening = true;

		    String address = (String) InetAddress.getLocalHost().getHostAddress();
			String msg     =    "Listening on address [" + address + "] and " +
							    "port [" + port + "] with a backlog of [" + backLog +"].";
			System.out.println(msg);
			
			logger.info( " " );
		    logger.info( "********************************************************************************" );
			logger.info( msg );
		    logger.info( "********************************************************************************" );
			logger.info( " " );

		    //if ( logger.isDebugEnabled() )
			//{
				//logger.debug( msg );
				//logger.debug( TemplateManager.display() );
				//logger.debug( PropertyManager.display() );
			//}

			this.start();
		}
		catch (Exception e)
		{
			listening = false;
			e.printStackTrace();

			logger.fatal( e.getMessage() );

			doShutdown();
		}
	}


	/**
	 * This is where this server's thread does all of
	 * its listening and handling for incoming requests.
	 * This process automatically "starts" when this object is instantiated.
	 */
	public void
	run()
	{
		try
		{
			Thread        thread  = null;
			MessageThread message = null;

			while ( (listening) && (server != null) )
			{
				client  = (Socket)        server.accept();
				message = (MessageThread) new MessageThread( (Socket) client );
				thread  = (Thread)        new Thread( threadGroup, message );
				thread.start();

				if ( logger.isDebugEnabled() )
				{
					logger.debug( "Starting a new MessageThread." );
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			logger.fatal( e.getMessage() );
		}
		finally
		{
			try
			{
				if ( client != null ) { client.close(); }
				if ( server != null ) { server.close(); }
			}
			catch (Exception e2)
			{
				e2.printStackTrace();
				logger.fatal( e2.getMessage() );
			}
			finally
			{
				doShutdown();
			}
		}
	}


	/**
	 * Performs a shutdown of this server.
	 * First, it triggers for the server to stop listening for requests.
	 * Then, it waits until all current threads complete their tasks.
	 * Finally, it shuts the server off and exits the JVM.
	 */
	public static void
	doShutdown()
	{
		doShutdown( null );
	}


	/**
	 * Performs a shutdown of this server.
	 * First, it triggers for the server to stop listening for requests.
	 * Then, it waits until all current threads complete their tasks.
	 * Finally, it shuts the server off and exits the JVM.
	 *
	 * @param p_params optional parameters ... (currently ignored).
	 */
	public static void
	doShutdown( String [] p_params )
	{
		
		logger.info(        "Shutdown process initiated ..." );

		try
		{
			listening = false;

			while ( threadGroup.activeCount() > 0 )
			{
				//System.out.println( "sleeping ..." );
				Thread.currentThread().sleep( 250 );
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			logger.error( "Shutdown process caused an error: " + e.getMessage() );
		}

		
		logger.info(        "Shutdown process completed successfully." );
		System.exit( 0 );
	}
}