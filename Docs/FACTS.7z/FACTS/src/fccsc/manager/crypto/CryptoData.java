package fccsc.manager.crypto;


public final class CryptoData
{
	private byte [] data       = {};
	private byte [] sessionKey = {};


	public
	CryptoData( byte [] p_data, byte [] p_sessionKey )
	{
		this.data       = p_data;
		this.sessionKey = p_sessionKey;
	}


	public byte [] getData()       { return this.data; }
	public byte [] getSessionKey() { return this.sessionKey; }
	public boolean isEncrypted()   { return (boolean) (sessionKey == null) ? false : true; }
}