package fccsc.manager.apps.tester;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

import javax.swing.*;

import org.apache.log4j.*;

import intarsys.util.*;

import fccsc.manager.crypto.MessageCryptography;


public class MessageTester
	extends JFrame
{
    private MainPanel panelMain = new MainPanel();


	public static void
	main( String [] args )
	{
		try
		{
			/////////////////////////////////////////////////////////////
			//
			// get the current directory path
			File f = new File( "." );

			///////////////////////////////////////////////////////////////
			// load the properties files
			// and fetch parameter values for this object's construction
			//
			PropertyManager.init( f.getCanonicalPath() + f.separator + "properties" );
			PropertyManager.loadAll();

			///////////////////////////////////////////////////////////////
			// load the log4j properties
			//
			Properties propLog4j = (Properties) PropertyManager.getProperty( "log4j.properties" );
			PropertyConfigurator.configure( propLog4j );

			///////////////////////////////////////////////////////////////
			// initialize our cryptography object
			//
			Properties propCrypto = ( Properties ) PropertyManager.getProperty( "cryptography.properties" );
			MessageCryptography.init( propCrypto );
		}
		catch (IOException ex)
		{
			ex.printStackTrace();
		}

		MessageTester tester = new MessageTester();
		tester.setSize( 700, 600 );
		tester.setVisible( true );
	}



    public MessageTester()
    {
        try
        {
            jbInit();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    private void jbInit() throws Exception
    {
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setTitle("Message Tester");
        this.addWindowListener(new java.awt.event.WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                this_windowClosing(e);
            }
        });
        this.getContentPane().add(panelMain, BorderLayout.CENTER);
    }

    void this_windowClosing(WindowEvent e)
    {
		System.exit( 0 );
    }
}