package fccsc.manager.apps.tester;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;

import intarsys.util.*;
import intarsys.xml.*;

import fccsc.manager.*;
import fccsc.manager.crypto.*;
import fccsc.manager.data.edi.*;
import fccsc.manager.data.xml.*;


public class MainPanel
	extends JPanel
	implements Observer
{
	private final String DATE_FORMAT = "HH:mm:ss:SSS";

	private final String [][] arrProcesses = {  { "EDI - Verify",       "VERIFY"     },   // 0
												{ "EDI - Course List",  "COURSELIST" },   // 1
												{ "EDI - Transcript",   "TRANSCRIPT" },   // 2
												{ "EDI - Degree Audit", "GRADAUDIT"  },   // 3
												{ "EDI - Local Shop",   "LOCALSHOP"  },   // 4
												{ "EDI - FACTS Shop",   "FACTSSHOP"  },   // 5
												{ "EDI - Remote Shop",  "REMOTESHOP" },   // 6
												{ "XML - Admission",    "ADMISSION"  },   // 7
												{ "XML - 22 Advise",    "22ADVISE"   } }; // 8
	private String callbackIpAddress = "";
	private String callbackIpPort    = "";
	private String sendtoIpAddress   = "";
	private int    sendtoIpPort      = 0;
	private int    threadsCount      = 1;
	private int    encryptionIndex   = 0;
	private String data              = "";

	public static Hashtable hashSessionKeys = new Hashtable( 2 );


    private JPanel jPanel2 = new JPanel();
    private BorderLayout borderLayout1 = new BorderLayout();
    private GridBagLayout gridBagLayout1 = new GridBagLayout();
    private Border border1;
    private Border border2;
    private Border border3;
    private TitledBorder titledBorder2;
    private JSplitPane jSplitPane1 = new JSplitPane();
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JTextArea areaSent = new JTextArea();
    private JScrollPane jScrollPane2 = new JScrollPane();
    private JTextArea areaRecieved = new JTextArea();
    private JPanel jPanel3 = new JPanel();
    private JLabel labelStatus = new JLabel();
    private Border border5;
    private GridBagLayout gridBagLayout3 = new GridBagLayout();
    private JPanel jPanel4 = new JPanel();
    private JPanel jPanel1 = new JPanel();
    private JTextField fieldPinPassword = new JTextField();
    private GridBagLayout gridBagLayout2 = new GridBagLayout();
    private JTextField fieldStudentId = new JTextField();
    private JComboBox comboProcesses = new JComboBox();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel1 = new JLabel();
    private GridBagLayout gridBagLayout4 = new GridBagLayout();
    private Border border4;
    private TitledBorder titledBorder1;
    private JPanel jPanel5 = new JPanel();
    private JTextField fieldIpAddress = new JTextField();
    private JTextField fieldIpPort = new JTextField();
    private GridBagLayout gridBagLayout5 = new GridBagLayout();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel7 = new JLabel();
    private Border border6;
    private TitledBorder titledBorder3;
    private JLabel jLabel4 = new JLabel();
    private JComboBox comboThreads = new JComboBox();
    private JButton buttonSend = new JButton();
    private JLabel jLabel5 = new JLabel();
    private JComboBox comboEncryption = new JComboBox();

    public MainPanel()
    {
        try
        {
            jbInit();

		    initCryptography();

			startListener();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    private void jbInit() throws Exception
    {
        border1 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
        border2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142)),"Message Information");
        border3 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
        titledBorder2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142)),"Message Sent / Received");
        border5 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
        border4 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
        titledBorder1 = new TitledBorder(border4,"Destination Information");
        border6 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
        titledBorder3 = new TitledBorder(border6,"Destination Information");
        jPanel2.setLayout(gridBagLayout1);
        this.setLayout(borderLayout1);
        jPanel2.setBorder(titledBorder2);
        jScrollPane1.getViewport().setBackground(Color.black);
        areaSent.setText("Ready to Send . . .");
        areaSent.setEditable(false);
        areaSent.setForeground(Color.green);
        areaSent.setFont(new java.awt.Font("Monospaced", 1, 12));
        areaSent.setBackground(Color.black);
        areaRecieved.setBackground(Color.green);
        areaRecieved.setFont(new java.awt.Font("Monospaced", 1, 12));
        areaRecieved.setEditable(false);
        areaRecieved.setText("Ready to Receive . . .");
        jSplitPane1.setLastDividerLocation(300);
        jSplitPane1.setOneTouchExpandable(true);
        labelStatus.setForeground(Color.black);
        labelStatus.setText("Ready ...");
        jPanel3.setLayout(gridBagLayout3);
        jPanel3.setBorder(border5);
        jPanel1.setLayout(gridBagLayout2);
        jPanel1.setBorder(border2);
        fieldPinPassword.setFont(new java.awt.Font("Dialog", 1, 12));
        fieldPinPassword.setForeground(Color.blue);
        fieldPinPassword.setText("0969");
        fieldPinPassword.setColumns(9);
        fieldStudentId.setFont(new java.awt.Font("Dialog", 1, 12));
        fieldStudentId.setForeground(Color.blue);
        fieldStudentId.setText("000000006");
        fieldStudentId.setColumns(9);
        jLabel3.setText("Message");
        jLabel2.setText("Student Id");
        jLabel1.setText("Pin / Password");
        jPanel4.setLayout(gridBagLayout4);
        jPanel5.setLayout(gridBagLayout5);
        fieldIpAddress.setFont(new java.awt.Font("Dialog", 1, 12));
        fieldIpAddress.setForeground(Color.red);
        fieldIpAddress.setText("localhost");
        fieldIpAddress.setColumns(15);
        fieldIpPort.setFont(new java.awt.Font("Dialog", 1, 12));
        fieldIpPort.setForeground(Color.red);
        fieldIpPort.setText("5100");
        fieldIpPort.setColumns(5);
        jLabel6.setText("IP Port");
        jLabel7.setText("IP Address");
        jPanel5.setBorder(titledBorder3);
        jLabel4.setText("Threads");
        buttonSend.setText("Send");
        buttonSend.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                buttonSend_actionPerformed(e);
            }
        });
        jLabel5.setText("Encrypt");
        comboProcesses.setMaximumRowCount(12);
        comboThreads.setMaximumRowCount(12);
        this.add(jPanel2,  BorderLayout.CENTER);
        this.add(jPanel3,  BorderLayout.SOUTH);
        jPanel2.add(jSplitPane1,     new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(3, 3, 3, 3), 0, 0));
        jPanel3.add(labelStatus,    new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        this.add(jPanel4, BorderLayout.NORTH);
        jPanel4.add(jPanel1,              new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.NORTH, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        jPanel1.add(comboProcesses,              new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 0, 0));
        jPanel1.add(jLabel1,            new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 0, 0));
        jPanel1.add(fieldPinPassword,            new GridBagConstraints(1, 1, 2, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 9, 0));
        jPanel1.add(jLabel2,            new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 3, 3, 3), 0, 0));
        jPanel1.add(fieldStudentId,            new GridBagConstraints(1, 0, 2, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 9, 0));
        jPanel1.add(jLabel3,               new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 0, 0));
        jPanel1.add(buttonSend,          new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 0, 0));
        jPanel4.add(jPanel5,            new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.NORTH, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        jPanel5.add(jLabel7, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 0, 0));
        jPanel5.add(fieldIpAddress, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 15, 0));
        jPanel5.add(fieldIpPort, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 5, 0));
        jPanel5.add(jLabel6, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 0, 0));
        jPanel5.add(jLabel4,    new GridBagConstraints(0, 2, 1, 1, 0.0, 1.0
            ,GridBagConstraints.NORTHEAST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 0, 0));
        jPanel5.add(comboThreads,   new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 0, 0));
        jSplitPane1.setDividerLocation(350);
        jScrollPane1.getViewport().add(areaSent, null);
        jScrollPane2.getViewport().add(areaRecieved, null);
		jSplitPane1.setOrientation( JSplitPane.HORIZONTAL_SPLIT );
        jSplitPane1.add(jScrollPane1, JSplitPane.LEFT);
        jSplitPane1.add(jScrollPane2, JSplitPane.RIGHT);
        jPanel1.add(jLabel5,       new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 0, 0));
        jPanel1.add(comboEncryption,         new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 0, 0));


		// load the messages combo listing
		for ( int i = 0; i < arrProcesses.length; i++ )
		{
			comboProcesses.insertItemAt( arrProcesses[i][0], i );
		}
	    comboProcesses.setSelectedIndex( 0 );

		comboThreads.insertItemAt(  "1",  0 );
		comboThreads.insertItemAt(  "2",  1 );
		comboThreads.insertItemAt(  "3",  2 );
		comboThreads.insertItemAt(  "4",  3 );
		comboThreads.insertItemAt(  "5",  4 );
		comboThreads.insertItemAt( "10",  5 );
		// load the thread count combo
		for ( int i = 1; i <= 6; i++ )
		{
			comboThreads.insertItemAt( "" + (i * 25), i + 5 );
		}
		comboThreads.setSelectedIndex( 0 );


		comboEncryption.insertItemAt(  "No",  0 );
		comboEncryption.insertItemAt( "Yes",  1 );
		comboEncryption.setSelectedIndex( 0 );
    }

    void buttonSend_actionPerformed(ActionEvent e)
    {
		process();

		areaRecieved.setCursor( Cursor.getPredefinedCursor( Cursor.WAIT_CURSOR ) );
    }


	private void
	initCryptography()
	{
//		this.crypto.init();
	}


	private void
	startListener()
	{
		Properties prop      = (Properties) PropertyManager.getProperty( "manager.properties" );
		this.callbackIpPort  = (String)     prop.getProperty( "tester.listener.port" );
		int listeningPort    = (int) Integer.parseInt( callbackIpPort );
		int listeningBackLog = (int) Integer.parseInt( (String) prop.getProperty( "tester.listener.backlog" ) );

		new DataListener( listeningPort, listeningBackLog, this );

		try { this.callbackIpAddress = (String) InetAddress.getLocalHost().getHostAddress(); }
		catch (UnknownHostException ex) { ex.printStackTrace(); }

		labelStatus.setText( "  Listening on ip [" + callbackIpAddress + "] and port [" + listeningPort + "] with a backlog of [" + listeningBackLog + "]." );

		this.callbackIpAddress = StringTools.padRight( this.callbackIpAddress, 15, ' ' );
		this.callbackIpPort    = StringTools.padLeft(  this.callbackIpPort,     5, '0' );

		this.fieldIpPort.setText( (String) prop.getProperty( "manager.listener.port" ) );
	}


	private void
	process()
	{
		String studentId      = (String) fieldStudentId.getText();
		String studentPin     = (String) fieldPinPassword.getText();
		int    processIndex   = (int)    comboProcesses.getSelectedIndex();
		String process        = (String) arrProcesses[ processIndex ] [1];
		String threadsValue   = (String) comboThreads.getSelectedItem();
		String enc            = "0";

		this.threadsCount    = (int)    Integer.parseInt( threadsValue );
		this.sendtoIpAddress = (String) fieldIpAddress.getText();
		this.sendtoIpPort    = (int)    Integer.parseInt( (String) fieldIpPort.getText() );
		this.encryptionIndex = (int)    comboEncryption.getSelectedIndex();

		process    = StringTools.padRight( process,    10, ' ' );
		studentId  = StringTools.padRight( studentId,  12, ' ' );
		studentPin = StringTools.padRight( studentPin, 15, ' ' );

		if ( sendtoIpAddress.trim().equalsIgnoreCase( "localhost" ) )
		{
			sendtoIpAddress = this.callbackIpAddress;
		}

		if ( encryptionIndex == 1 ) { enc = "3"; }


		// EDI message
		if ( (processIndex == 0) || // Verify
			 (processIndex == 1) || // Course List
			 (processIndex == 2) || // Transcript
			 (processIndex == 3) || // Degree Audit
			 (processIndex == 4) || // Local Shop
			 (processIndex == 5) || // FACTS Shop
			 (processIndex == 6)  ) // Remote Shop
		{
			data = "" +
			"000736TCP FEDI0" + enc + "FLACENTSERV0008887000001010                 " +
			"        000001REQUEST Y\n" +
			"        000010PROCESS " + process + "\n" +
			"        000016STATEKEYT0001274M0000006\n" +
			"        000015IPADDRES" + this.callbackIpAddress + "\n" +
			"        000005PORTNUMB" + this.callbackIpPort    + "\n" +
			"        000050RETNDATAWA00,                           SWWP0F00P0001282  \n" +
			"        000030HTMLKEY                               \n" +
			"        000012STUID   " + studentId  + "\n" +
			"        000015PIN/PW  " + studentPin + "\n" +
			"        000001WAIT    N\n" +
			"        000005RETNCODE00000\n" +
			"        000240RETNMESS                                                                                                                                                                                                                                                \n";

			if ( (processIndex == 4) || // Local Shop
				 (processIndex == 5) || // FACTS Shop
				 (processIndex == 6)  ) // Remote Shop
			{
				ControlBlock      ediCB  = new ControlBlock( data );
				StandardDataBlock ediSDB = new StandardDataBlock( data );
				StringBuffer      ediPDB = new StringBuffer();

				ediPDB.append( (String) StringTools.padRight( "",  8, ' ' ) );
				ediPDB.append( (String) "000010MAJOR   " );
				ediPDB.append( (String) "10504     " );
				ediPDB.append( (String) "\n" );
				ediPDB.append( (String) StringTools.padRight( "",  8, ' ' ) );
				ediPDB.append( (String) "000006CATLYEAR" );
				ediPDB.append( (String) "200201" );
				ediPDB.append( (String) "\n" );

				if ( (processIndex == 5) || // FACTS Shop
					 (processIndex == 6)  ) // Remote Shop
				{
					ediPDB.append( (String) StringTools.padRight( "", 8, ' ' ) );
					ediPDB.append( (String) "000001ASSUMEAA" );
					ediPDB.append( (String) "Y" );
					ediPDB.append( (String) "\n" );

					// attach the CLB (Course List Block)
					ediPDB.append( "        000100DEMOGRAF001512 1   000000006CHRISTOPHER MARK HARRIS                                     19690918NNN         \n" );
					ediPDB.append( "        000119COURSLST198808 0001512      ENC 1101        FRESHMAN COMM I          ENC 1101        0 W  003000        U S                    \n" );
					ediPDB.append( "        000119COURSLST198808 0001512      JOU 1100        MASS COMM                MMC 1100        0 W  003000        U S                    \n" );
					ediPDB.append( "        000119COURSLST198808 0001512      MGF 1103        GENERAL ED MATH I        MGF 1103        0 W  003000        U S                    \n" );
					ediPDB.append( "        000119COURSLST198808 0001512      PEL 2341        BEGINNING TENNIS         PEL 2341        0 W  001000        U S                    \n" );
					ediPDB.append( "        000119COURSLST198808 0001512      POS 2041        AMER NATIONAL GOVERN     POS 1041        0 W  003000        U S                    \n" );
				}


				int lenTotal = ediCB.getData().length() + ediSDB.getData().length() + ediPDB.length();

				ediCB.setTotalRecordSize( (String) String.valueOf( (int) lenTotal ) );

				data = (String) ediCB.getData() + ediSDB.getData() + ediPDB.toString();
			}
		}

		// XML message - ADMISSION
		else if ( processIndex == 7 ) // Admissions
		{
			data = "" +
			"001308TCP FXML0" + enc + "FLACENTSERV0008887000001010                 " +
			"<?xml version='1.0'?>" +
			"<FACTS_MESSAGE Process='ADMISSION' Request='Y' Wait='N'>" +
				"<STANDARD_BLK>" +
	    			"<STATEKEY>T0001274M0000006</STATEKEY>" +
		    		"<IPADDRESS>" + this.callbackIpAddress + "</IPADDRESS>" +
			    	"<PORT>"      + this.callbackIpPort    + "</PORT>" +
				    "<RETNDATA>WA00,                           SWWP0F00P0001282  </RETNDATA>" +
					"<HTMLKEY>;2C;;2001;</HTMLKEY>" +
	    			"<STUID>"     + studentId  + "</STUID>" +
		    		"<PIN_PW>"    + studentPin + "</PIN_PW>" +
			    	"<RETNCODE>00000</RETNCODE>" +
				    "<RETNMESS></RETNMESS>" +
				"</STANDARD_BLK>" +
				"<ADMISSION_REQ FACTS_ID=''>" +
					"<HIGH_SCHOOL/>" +
					"<PREV_INST END_MON='' BEG_YR='' BEG_MON='' END_YR=''/>" +
					"<FLA_RESIDENCY/>" +
					"<NON-US_INFO/>" +
					"<ADM_TEST DAY='' MON='' YR=''>" +
						"<TEST_TYPE_CD></TEST_TYPE_CD>" +
						"<TEST_SCORE></TEST_SCORE>" +
					"</ADM_TEST>" +
					"<COURSE CredType='' CredHrs='' DAY='' MON='' CrsNbr='' YR='' CrsStatus='C'>" +
						"<INST_NAME></INST_NAME>" +
						"<COURSE_TITLE></COURSE_TITLE>" +
					"</COURSE>" +
					"<ACTIVITY END_MON='' BEG_YR='' BEG_MON='' END_YR='' OccCode=''>" +
						"<CITY></CITY>" +
						"<STATE></STATE>" +
						"<COUNTRY Code=''></COUNTRY>" +
					"</ACTIVITY>" +
					"<ALUMNI_INFO>" +
						"<NAME Relationship=''>" +
							"<LAST_NAME/>" +
							"<FIRST_NAME/>" +
							"<MIDDLE_NAME></MIDDLE_NAME>" +
							"<SUFFIX></SUFFIX>" +
						"</NAME>" +
						"<UNIVERSITY></UNIVERSITY>" +
					"</ALUMNI_INFO>" +
					"<FAMILY_INFO Relationship=''>" +
						"<HIGHEST_ED></HIGHEST_ED>" +
						"<OCCUPATION></OCCUPATION>" +
					"</FAMILY_INFO>" +
					"<OBLIGATION OblType='W'></OBLIGATION>" +
					"<EXTRACURRICULAR ActType=''></EXTRACURRICULAR>" +
				"</ADMISSION_REQ>" +
			"</FACTS_MESSAGE>";
		}

		// XML message - 22ADVISE
		else if ( processIndex == 8 ) // 22 Advise
		{
			data = "" +
			"000554TCP FXML0" + enc + "FLACENTSERV0008887000001010                 " +
			"<?xml version='1.0'?>" +
			"<FACTS_MESSAGE Process='22ADVISE' Request='Y' Wait='N'>" +
				"<STANDARD_BLK>" +
	    			"<STATEKEY>T0001274M0000006</STATEKEY>" +
		    		"<IPADDRESS>" + this.callbackIpAddress + "</IPADDRESS>" +
			    	"<PORT>"      + this.callbackIpPort    + "</PORT>" +
				    "<RETNDATA>WA00,                           SWWP0F00P0001282  </RETNDATA>" +
					"<HTMLKEY>;2C;;2001;</HTMLKEY>" +
	    			"<STUID>"     + studentId  + "</STUID>" +
		    		"<PIN_PW>"    + studentPin + "</PIN_PW>" +
			    	"<RETNCODE>00000</RETNCODE>" +
				    "<RETNMESS></RETNMESS>" +
				"</STANDARD_BLK>" +
		    	"<ADVISE22_REQ>" +
		   	    	"<MAJOR>10504</MAJOR>" +
			    	"<CATLYEAR>2001</CATLYEAR>" +
	    	    "</ADVISE22_REQ>" +
			"</FACTS_MESSAGE>";
		}


		///////////////////////////////////////////////////////////////////////////////////
		// send data
		//
		try
		{
			if ( this.threadsCount == 1 )
			{
				areaSent.setText( "[" + new SimpleDateFormat( DATE_FORMAT ).format( new Date() ) + "]\n" );
	    		areaRecieved.setText( "Waiting for data ..." );

				byte [] dataBytes = data.getBytes();

				// check for encryption usage
				//
				if ( MainPanel.this.encryptionIndex == 1 ) // Yes
				{
				    int id = 1;
				    data = setMessageId( data, id );

				    CryptoData crypdata = (CryptoData) MessageCryptography.encrypt( data );

				    dataBytes = crypdata.getData();

				    hashSessionKeys.put( (String) String.valueOf( id ), (CryptoData) crypdata );
				}

				MessageSender sender = new MessageSender( sendtoIpAddress, sendtoIpPort );
				sender.send( dataBytes );

				if ( MainPanel.this.encryptionIndex == 1 )
				{
					areaSent.append( "\nENCRYPTED" );
				}
				areaSent.append( "\nData sent ....... (" + data.length() + ")" );
				areaSent.append( "\n[" + data + "]" );
				areaSent.append( "\nData received ... ["   + sender.getDataReceived() + "]" );
			}
			else
			{
				areaSent.setText(     "Sending " + this.threadsCount + " threads ... \n" );
	    		areaRecieved.setText( "Waiting for " + this.threadsCount + " threads ... \n" );

				for ( int i = 0; i < this.threadsCount; i++ )
				{
					new SenderThread( i ).start();
				}
			}
		}
		catch (Exception ex)
		{
			areaSent.setText( "EXCEPTION ...\n" );
			areaSent.append( "\n* * * * * * * * * * * * * * * * * * * * * * * * * * *" );
			areaSent.append( "\n" + ex.getMessage() );
			areaSent.append( "\n* * * * * * * * * * * * * * * * * * * * * * * * * * *" );

			areaRecieved.setText( "<--- An exception occurred !" );
		}
	}


	/*
	 * Interface Method.
	 */
	public void
	update( Observable o, Object arg )
	{
		CryptoData crypdata = (CryptoData) arg;

		if ( this.threadsCount == 1 )
		{
			areaRecieved.setText( "[" + new SimpleDateFormat( DATE_FORMAT ).format( new Date() ) + "]\n" );

			if ( crypdata.isEncrypted() )
			{
				areaRecieved.append( "\nENCRYPTED" );
			}
			areaRecieved.append( "\nData received ... (" + crypdata.getData().length + ")" );
			areaRecieved.append( "\n[" + new String( crypdata.getData() ) + "]" );
			areaRecieved.setCursor( Cursor.getDefaultCursor() );
		}
		else
		{
		    areaRecieved.append( "\nReceived ... (" + crypdata.getData().length + ") " );
		    areaRecieved.append( "[" + new SimpleDateFormat( DATE_FORMAT ).format( new Date() ) + "]" );
			if ( crypdata.isEncrypted() )
			{
				areaRecieved.append( " ENCRYPTED" );
			}
			//areaRecieved.append( "\n[" + arg + "]" );
		}
	}

    void buttonExit_actionPerformed(ActionEvent e)
    {
		System.exit( 0 );
    }


	public static String
	setMessageId( String p_data, int p_messageId )
	{
		StringBuffer buffer = new StringBuffer( p_data );

		String id = StringTools.padLeft( String.valueOf( p_messageId ), 6, ' ' );

		for ( int i = 0; i < id.length(); i++ )
		{
			buffer.setCharAt( 54 + i, id.charAt( i ) );
		}

	    return (String) buffer.toString();
	}


	public static String
	getMessageId( byte [] p_data )
	{
		StringBuffer buffer = new StringBuffer();

		for ( int i = 0; i < 6; i++ )
		{
			buffer.append( (char) p_data[ 54 + i ] );
		}

		return (String) buffer.toString();
	}



	class SenderThread
		extends Thread
	{
		private int id = 0;

		public
		SenderThread( int p_id )
		{
			this.id = p_id;
		}


		public void
		run()
		{
			try
			{
			    byte [] dataBytes = MainPanel.this.data.getBytes();

				if ( MainPanel.this.encryptionIndex == 1 ) // Yes
				{
				    String data = setMessageId( MainPanel.this.data, this.id );

				    CryptoData crypdata = (CryptoData) MessageCryptography.encrypt( data );

				    dataBytes = crypdata.getData();

				    hashSessionKeys.put( (String) String.valueOf( this.id ),(CryptoData) crypdata);
				}

				MessageSender sender2 = new MessageSender(
												MainPanel.this.sendtoIpAddress,
												MainPanel.this.sendtoIpPort );
				sender2.send( dataBytes );

				areaSent.append( "\nSent ... [" + this.getName() + "] " );
				areaSent.append( "[" + new SimpleDateFormat( DATE_FORMAT ).format(
															new Date() ) + "]" );

				if ( MainPanel.this.encryptionIndex == 1 )
				{ areaSent.append( " ENCRYPTED" ); }
			}
			catch (Exception ex) { ex.printStackTrace(); }
		}
	}
}