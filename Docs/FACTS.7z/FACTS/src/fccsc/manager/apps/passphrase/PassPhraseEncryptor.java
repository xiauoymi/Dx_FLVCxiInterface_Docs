package fccsc.manager.apps.passphrase;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;


public class PassPhraseEncryptor
	extends JFrame
{
    private MainPanel panelMain = new MainPanel();


	public static void
	main( String [] args )
	{
		PassPhraseEncryptor encryptor = new PassPhraseEncryptor();
		encryptor.setSize( 600, 200 );
		encryptor.setVisible( true );
	}


    public
	PassPhraseEncryptor()
    {
        try
        {
            jbInit();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    private void jbInit() throws Exception
    {
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
		this.setResizable(false);
	    this.setState(Frame.NORMAL);
        this.setTitle("Pass Phrase Encryptor");
        this.addWindowListener(new java.awt.event.WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                this_windowClosing(e);
            }
        });
        this.getContentPane().add(panelMain, BorderLayout.CENTER);
    }

    void this_windowClosing(WindowEvent e)
    {
		System.exit( 0 );
    }
}