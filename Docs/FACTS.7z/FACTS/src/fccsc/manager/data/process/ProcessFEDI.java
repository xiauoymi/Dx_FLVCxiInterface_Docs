package fccsc.manager.data.process;

import fccsc.manager.data.edi.*;


public abstract class ProcessFEDI
	extends Process
{
	private StandardDataBlock ediSDB = null;


    public
	ProcessFEDI( String p_propertiesFileName )
    {
		super( p_propertiesFileName );
    }

	/**
	 * Returns the EDI Standard Data Block parsed from the data.
	 * @return edi standard data block.
	 */
	public StandardDataBlock getEDIStandardDataBlock() { return this.ediSDB; }


	/**
	 * Sets the incoming data to process.
	 * @param p_data the data to be processed.
	 * @throws Exception
	 */
	public void
	setRequest( String p_data ) throws Exception
	{
		super.setRequest( p_data );

		int mysize = super.getRequest().length();
		//System.out.println("MySize from ProcessFEDI = " + mysize);
		if(mysize == 822) {
			this.ediSDB  = new StandardDataBlock( super.getRequest(), 762 );//mdt this is where it blows up.
		}else{
			this.ediSDB  = new StandardDataBlock( super.getRequest() );//mdt this is where it blows up.
		}
		
		//this.ediSDB = new StandardDataBlock( super.getRequest() );

		this.setCallBackIpAddress( (String) this.ediSDB.getIpAddress() );
		this.setCallBackIpPort(    (int)    Integer.parseInt( (String) this.ediSDB.getIpPort() ) );
	}
}