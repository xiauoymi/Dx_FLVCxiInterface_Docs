package fccsc.manager.data.process;

import intarsys.util.*;
import intarsys.xml.*;

import edu.fscj.student.StudentPasswordClient;
import fccsc.manager.broker.*;
import fccsc.manager.data.*;
import fccsc.manager.data.xml.*;



public final class Advise22
	extends ProcessFXML
{
    public
	Advise22()
    {
		super( "message.22ADVISE.properties" );
    }


	/**
	 * Interface Method - Processing method.
	 */
	public void
	process() throws Exception
	{
		super.process();
	    
		StudentPasswordClient client = new StudentPasswordClient();
		String logonid = this.getXMLFactsMessage().getStudentID().trim();
		String ssn = client.getStudentSSNFromMIS(logonid);
		this.getXMLFactsMessage().setStudentID(ssn);
		
		String data = this.getXMLFactsMessage().getXML();
		
		
		EntireXBroker broker = new EntireXBroker( this.getProperties() );
		broker.sendMessage( data );

		// get response message
		String response   = broker.getResponse().trim();
		String resRC      = ReturnCodes.CODE_00000;
		String resMessage = ReturnCodes.CODE_00000_MESSAGE;

		if ( logger.isDebugEnabled() )
		{
			logger.debug( "Broker Response [" + response + "]" );
		}

		if ( response.trim().length() == 0 )
		{
			resRC      = ReturnCodes.CODE_00012;
			resMessage = ReturnCodes.CODE_00012_MESSAGE;

			logger.error( "Error [" + resRC + " - " + resMessage + "]" );
		}
		else
		{
			/////////////////////////////////////////////////////////////////
			// test to check if data is an xml ERROR structure
			//
			ErrorHandler handler = new ErrorHandler();
			
			new SAXManager().parseSAXString( handler, response.trim() );

			if ( handler.isErrorMessage() )
			{
				this.getXMLFactsMessage().setRequestData( "" );

				resRC      = ReturnCodes.CODE_00200;
				resMessage = handler.getStatus();
				response   = this.getXMLFactsMessage().getXML();

				logger.error( "Error [" + resRC + " - " + resMessage + "]" );
			}
		}

		this.getXMLFactsMessage().setReturnCode(    resRC      );
		this.getXMLFactsMessage().setReturnMessage( resMessage );

		//////////////////////////////////////////////////////////////
		// build response and store
		//
		int lenTotal = this.getEDIControlBlock().SIZE + response.length();

		this.getEDIControlBlock().setTotalRecordSize( String.valueOf( (int) lenTotal ) );
		
		//fix studentid switch
         //find <STUID>281686344</STUID> replace with <STUID>thomm20</STUID>
		String findValue = "<STUID>" + ssn + "</STUID>";
		String newValue = "<STUID>" + logonid + "</STUID>";
		response = response.replaceAll(findValue, newValue);
		findValue = "<StuID>" + ssn + "</StuID>";
		newValue = "<StuID>" + logonid + "</StuID>";
		response = response.replaceAll(findValue, newValue);	
		
		lenTotal = this.getEDIControlBlock().SIZE + response.length();
		this.getEDIControlBlock().setTotalRecordSize( String.valueOf( (int) lenTotal ) );
		
		String myResponse = this.getEDIControlBlock().getData() + response;

		
		
		this.setResponse( this.getEDIControlBlock().getData() + response );
		
		System.out.println("_______________________________________________________________________");
		System.out.println("Response back starts for Advise22");
		System.out.println(this.getResponse());
		System.out.println("End of Response");
		System.out.println("_______________________________________________________________________");
	}
}