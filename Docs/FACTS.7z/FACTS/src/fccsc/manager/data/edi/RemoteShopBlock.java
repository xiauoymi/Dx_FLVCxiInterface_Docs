package fccsc.manager.data.edi;

public class RemoteShopBlock
	extends LocalShopBlock
{
	public static final int SIZE = LocalShopBlock.SIZE + 24;


    public
	RemoteShopBlock( String p_data )
    {
		super( (String) p_data );
    }

	public String getAssumeAA() { return this.data.substring( 84, 84 + 1 ).trim(); }


	public String
	toString()
	{
		StringBuffer buffer = new StringBuffer();

		buffer.append( "\nRemote Shop Block" );
		buffer.append( "\n   Assume AA [" + getAssumeAA() + "]" );
		buffer.append( "\n   Parent [" + super.toString() + "]" );
		buffer.append( "\n" );

		return (String) buffer.toString();
	}
}