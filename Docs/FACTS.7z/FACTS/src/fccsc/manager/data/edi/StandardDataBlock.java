package fccsc.manager.data.edi;

import intarsys.util.*;


public final class StandardDataBlock
	extends AbstractBlock
{
	//public static final int SIZE = 676;
	public static final int SIZE = 817; //or 877
	

    public
	StandardDataBlock( String p_data )
    {    	
    	super( (String) p_data.substring( ControlBlock.SIZE, ControlBlock.SIZE + SIZE ) );
    	//super( (String) p_data.substring( p_data.indexOf("000001REQUEST"), p_data.indexOf("000001REQUEST") + p_data.length()+1 ) );
    	
    	   	
		
    }
    public
    StandardDataBlock( String p_data, int newSize )
    {    	
    	super( (String) p_data.substring( ControlBlock.SIZE, ControlBlock.SIZE + newSize ) );
    	
    
    	   	
		
    }

	public String getRequest()       { return StringTools.substring( data,  22,   1 ); }
	public String getProcess()       { return StringTools.substring( data,  46,  10 ); }
	public String getStateKey()      { return StringTools.substring( data,  79,  16 ); }
	public String getIpAddress()     { return StringTools.substring( data, 118,  15 ); }
	public String getIpPort()        { return StringTools.substring( data, 156,   5 ); }
	public String getReturnData()    { return StringTools.substring( data, 184,  50 ); }
	public String getHTMLKey()       { return StringTools.substring( data, 257,  30 ); }
	public String getStudentID()     { return StringTools.substring( data, 310,  40 ); }
	public String getPinPassword()   { return StringTools.substring( data, 373,  128 ); }
	public String getWait()          { return StringTools.substring( data, 524,   8 ); }
	public String getReturnCode()    { return StringTools.substring( data, 548,   5 ); }
	public String getReturnMessage() { return StringTools.substring( data, 576, 240 ); }
	

	public void	setReturnCode( String p_code )
	{
	if(p_code.trim().equals("0000")) {
		p_code = "00000";
	}
		int value = this.getData().length();
		String code = StringTools.padRight( p_code, 5, ' ' );
		if (value == 762) {
			this.data.replace( 407, 407 + 5, code );	
			//this.data.replace( 548, 548 + 5, code );
		}else{
			this.data.replace( 548, 548 + 5, code );
		}
		
		
	}

	
	public void setStudentIDandPass(String studentid, String password) {
		
		studentid  = (String) StringTools.padRight( studentid,  12, ' ' );
		password = (String) StringTools.padRight( password, 15, ' ' );
		
		
		this.data.replace(310, 310 + 12, studentid);
		this.data.replace(373, 373 + 15, password);
		
	}
	
	public void
	setReturnMessage( String p_message )
	{
		String msg = StringTools.padRight( p_message, 240, ' ' );
		String rtnMessage = this.getData();
		int indx = rtnMessage.indexOf("000010MAJOR");
		if(indx > -1) {
			int begIndex = rtnMessage.indexOf("000010MAJOR");
			int endIndex = rtnMessage.length() - 1;
			String tmpString = "\n" + "        " + rtnMessage.substring(begIndex,endIndex);
			//msg = msg + "\n" + tmpString;
			this.data.replace( 576, 576 + 240, msg );
			this.data.replace(576 + 240,  576 + 240 + 75, tmpString);
			String tmps = this.getData();
		}else{

		this.data.replace( 576, 576 + 240, msg );
		}
	}


	public String
	toString()
	{
		StringBuffer buffer = new StringBuffer();

		buffer.append( "\nStandard-Data Block" );
		buffer.append( "\n   Request       [" + getRequest()       + "]" );
		buffer.append( "\n   Process       [" + getProcess()       + "]" );
		buffer.append( "\n   StateKey      [" + getStateKey()      + "]" );
		buffer.append( "\n   IpAddress     [" + getIpAddress()     + "]" );
		buffer.append( "\n   IpPort        [" + getIpPort()        + "]" );
		buffer.append( "\n   ReturnData    [" + getReturnData()    + "]" );
		buffer.append( "\n   HTMLKey       [" + getHTMLKey()       + "]" );
		buffer.append( "\n   StudentID     [" + getStudentID()     + "]" );
		buffer.append( "\n   PinPassword   [" + getPinPassword()   + "]" );
		buffer.append( "\n   Wait          [" + getWait()          + "]" );
		buffer.append( "\n   ReturnCode    [" + getReturnCode()    + "]" );
		buffer.append( "\n   ReturnMessage [" + getReturnMessage() + "]" );
		buffer.append( "\n" );

		return (String) buffer.toString();
	}
}