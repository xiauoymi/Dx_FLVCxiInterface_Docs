package fccsc.manager;

import java.util.*;

import org.apache.log4j.*;

import com.softwareag.entirex.aci.BrokerException;

import intarsys.util.*;

import fccsc.manager.data.*;
import fccsc.manager.data.edi.*;
import fccsc.manager.data.process.*;
import fccsc.manager.data.xml.*;


public final class MessageHandler
{
    private static Logger logger = Logger.getLogger( MessageHandler.class );

	private static Hashtable hashMessageProperties = new Hashtable( 10, 2 );

	private String            data    = "";
	private ControlBlock      ediCB   = null;
	private StandardDataBlock ediSDB  = null;
	private IMessage          message = null;
	private FactsMessage      xmlFM   = null;

	private Class             cls     = null;
	private String            process = "";
	private MessageProperties mprop   = null;



	/**
	 * Creates a MessageHandler object.
	 */
    public
	MessageHandler()
    {
    }


	/**
	 * Returns the IMessage object being processed.
	 * @return an object which implements IMessage or null.
	 */
	public IMessage getMessage() { return this.message; }


	/**
	 *
	 * @param p_data
	 */
	public void
	processRequest( String p_data )
	{
		this.data = p_data;
		
		try
		{
			this.ediCB = new ControlBlock( this.data );
			System.out.println("_______________________________________________________________________");
			System.out.println("Request in");
			System.out.println(this.data);
			System.out.println("Done with Request");
			System.out.println("_______________________________________________________________________");

			if ( ediCB.isFEDI() )
			{   
				int mysize = this.data.length();
				
				if(mysize == 822) {
					
					ediSDB  = new StandardDataBlock( this.data, 762 );//mdt this is where it blows up.
					System.out.println("Process called is " + ediSDB.getProcess().trim());
				}else{
				ediSDB  = new StandardDataBlock( this.data );//mdt this is where it blows up.
				System.out.println("Process called is " + ediSDB.getProcess().trim());
				}
				process = ediSDB.getProcess().trim();
				System.out.println("Process = " + process);

				// determine if incoming process is any of the following ...
				//     VERIFY, TRANSCRIPT, COURSELIST, GRADAUDIT
				//     LOCALSHOP, REMOTESHOP, FACTSSHOP
				// else process an "Unknown" EDI process
		    }
			else if ( ediCB.isFXML() )
			{
				xmlFM   = new FactsMessage( this.data );
				System.out.println("Process called is " + xmlFM.getProcess().trim());
				process = (String) xmlFM.getProcess().trim();
				System.out.println("Process = " + process);
				// determine if incoming process is any of the following ...
				//     ADMISSION, 22ADVISE
				// else process an "Unknown" XML process
			}
			else
			{
				logger.error( "Unknown data type. The following message is not FEDI nor FXML:\n[" + this.data + "]" );
			}

			loadProperties( process );

			if ( hashMessageProperties.containsKey( (String) process ) )
			{
				mprop        = (MessageProperties) hashMessageProperties.get( (String) process );
				cls          = (Class)    Class.forName( (String) mprop.getObject() );
				this.message = (IMessage) cls.newInstance();
			}
			else
			{
				if ( ediCB.isFEDI() ) { this.message = (IMessage) new ProcessUnknownFEDI(); }
				else                  { this.message = (IMessage) new ProcessUnknownFXML(); }
			}

			this.message.setRequest( this.data );
	    	this.message.process();
		}
		catch ( Exception ex )
		{    
			System.out.println("PDATA = " + p_data);
			System.out.println("");
			System.out.println("Error " + ex.getMessage());
		    String msg  = "ERROR [" + ReturnCodes.CODE_00032 + "-" + ReturnCodes.CODE_00032_MESSAGE + "]";
			String msgX = ex.toString();
	

			logger.fatal( msg  );
			logger.fatal( msgX );


		    ////////////////////////////////////////////////////
			// since an exception occurred ...
			// probably due to not being able to connect to broker
			// we must take the original message and plug-in
			// return code and message
			//
		    StringBuffer response = new StringBuffer();

			if ( ediCB.isFEDI() )
			{
				((ProcessFEDI) message).getEDIStandardDataBlock().setReturnCode(    ReturnCodes.CODE_00032 );
				((ProcessFEDI) message).getEDIStandardDataBlock().setReturnMessage( ReturnCodes.CODE_00032_MESSAGE );

				String extra = "";
				try { extra = message.getRequest().substring( ControlBlock.SIZE + StandardDataBlock.SIZE ); }
			    catch (Exception ex2) { logger.error( ex2.getMessage() ); }

				response.append( ((ProcessFEDI) message).getEDIControlBlock().getData() +
							     ((ProcessFEDI) message).getEDIStandardDataBlock().getData() +
								 (String) extra );
		    }
			else if ( ediCB.isFXML() )
			{
				((ProcessFXML) message).getXMLFactsMessage().setReturnCode(    ReturnCodes.CODE_00032 );
				((ProcessFXML) message).getXMLFactsMessage().setReturnMessage( ReturnCodes.CODE_00032_MESSAGE );

				response.append( ((ProcessFXML) message).getEDIControlBlock().getData() +
							     ((ProcessFXML) message).getXMLFactsMessage().getXML()  );
			}
			
			try { message.setResponse( response.toString() ); }
			catch (Exception ex2) { logger.error( ex2.getMessage() ); }
		}
	}


	private void
	loadProperties( String p_process )
	{
		p_process.trim().toUpperCase();

		if ( ! this.hashMessageProperties.containsKey( (String) p_process ) )
		{
		    Properties prop = (Properties) PropertyManager.getProperty(
								    "message." + p_process + ".properties" );
		    if ( prop != null )
		    {
				MessageProperties mprop = new MessageProperties( p_process, prop );

			    this.hashMessageProperties.put( (String) p_process, (MessageProperties) mprop );
				//System.out.println( mprop.toString() );
				logger.info( "Loaded properties for [" + p_process + "]" );
		    }
			else
			{
				logger.error( "Cannot load properties file for [" + p_process + "]" );
			}
		}
	}
}