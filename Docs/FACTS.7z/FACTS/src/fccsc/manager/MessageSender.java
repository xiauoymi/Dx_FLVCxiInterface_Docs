package fccsc.manager;

import java.io.*;
import java.net.*;

import org.apache.log4j.*;

import intarsys.util.*;


public final class MessageSender
{
    private static Logger logger = Logger.getLogger( MessageSender.class );

	private String       host         = "";
	private int          port         = 0;
	private byte []      dataSent     = {};
	private StringBuffer dataReceived = new StringBuffer();


//	public static void
//	main( String [] args )
//	{
//		//String studentId  = "000000003";
//		//String studentPin = "1257";
//		String studentId  = "100000006";
//		String studentPin = "0969";
//
//		String process    = "TRANSCRIPT"; //"COURSELIST"; //"VERIFY";
//		String ipAddress  = "";
//		String ipPort     = "05200";
//
//		try
//		{
//			ipAddress  = InetAddress.getLocalHost().getHostAddress();
//			ipAddress  = StringTools.padRight( ipAddress,  15, ' ' );
//
//			process    = StringTools.padRight( process,    10, ' ' );
//			studentId  = StringTools.padRight( studentId,  12, ' ' );
//			studentPin = StringTools.padRight( studentPin, 15, ' ' );
//		}
//		catch (UnknownHostException ex) { ex.printStackTrace(); }
//
//
//		String data = "" +
//		"000736TCP FEDI00FLACENTSERV0008887000001010                 " +
//		"        000001REQUEST Y\n" +
//		"        000010PROCESS " + process + "\n" +
//		"        000016STATEKEYT0001274M0000006\n" +
//		"        000015IPADDRES" + ipAddress + "\n" +
//		"        000005PORTNUMB" + ipPort    + "\n" +
//		"        000050RETNDATAWA00,                           SWWP0F00P0001282  \n" +
//		"        000030HTMLKEY                               \n" +
//		"        000012STUID   " + studentId  + "\n" +
//		"        000015PIN/PW  " + studentPin + "\n" +
//		"        000001WAIT    N\n" +
//		"        000005RETNCODE00000\n" +
//		"        000240RETNMESS                                                                                                                                                                                                                                                \n";
//
//
//
//		MessageSender sender = new MessageSender( "localhost", 5100 );
//		sender.send( data );
//
//		System.out.println( "[" + new java.util.Date().toString() + "]" );
//		System.out.println( "Data received ...["   + sender.getDataReceived() + "]" );
//		System.out.println( "Data sent .......[\n" + sender.getDataSent()     + "]" );
//		System.out.println( "* * * * * * * * * * * * * * * * * * * * * * * * * * *\n" );
//	}


	public
	MessageSender( String p_host, int p_port )
	{
		this.host = p_host;
		this.port = p_port;
	}


	public void
	send( String p_data ) throws Exception
	{
		send( p_data.getBytes() );
	}


	public void
	send( byte [] p_data ) throws Exception
	{
		this.dataSent = p_data;

		Socket         socket = null;
		InputStream    in     = null;
		OutputStream   out    = null;
		BufferedReader bin    = null;
		BufferedWriter bout   = null;

		try
		{
			if ( logger.isDebugEnabled() )
			{
				logger.debug( "Sending to    [" + this.host.trim() + ":" + this.port + "]" );
				logger.debug( "Data sent     [" + this.dataSent.length + "]" );
			}

			socket = new Socket( this.host, this.port );
			in     = (InputStream)  socket.getInputStream();
			out    = (OutputStream) socket.getOutputStream();
		    bin    = new BufferedReader( new InputStreamReader( in ) );
//			bout   = new BufferedWriter( new OutputStreamWriter( out ) );

//			bout.write( (String) this.dataSent );
//			bout.flush();
			out.write( this.dataSent );
			out.flush();
			socket.shutdownOutput();

			String line = "";
			while ( (line = (String) bin.readLine()) != null )
			{
				this.dataReceived.append( (String) line );
			}

			if ( logger.isDebugEnabled() )
			{
				logger.debug( "Data received [" + this.dataReceived.length() + " / " + this.dataReceived + "]" );
			}
		}
		catch (Exception e)
		{
			logger.fatal( "Communication with host: " + this.host + "and port: " + this.port + " Error = [" + e.getMessage() + "]" );
			throw e;
		}
		finally
		{
		    try
			{
				if ( in     != null ) { in.close(); }
	    		if ( out    != null ) { out.close(); }
		    	if ( bin    != null ) { bin.close(); }
			    if ( bout   != null ) { bout.close(); }
				if ( socket != null ) { socket.close(); }
			}
			catch (Exception e2)
			{
				logger.fatal( e2.getMessage(), e2 );
				throw e2;
			}
		}
	}


	public String getDataSent()     { return (String) new String( this.dataSent );  }
	public String getDataReceived() { return (String) this.dataReceived.toString(); }
}
